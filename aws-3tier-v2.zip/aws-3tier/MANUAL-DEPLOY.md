# Manual deployment walkthrough (Console, step by step)

## Architecture
```
Internet --> ALB (public, :80)
              |-- /api/*  --> Target group "tg-backend"  (port 3000) --> EC2 backend --> RDS PostgreSQL (private, :5432, SSL verified)
              |-- default --> Target group "tg-frontend" (port 80)   --> EC2 frontend (nginx, static files)
```
One ALB, path-based routing. The browser only ever talks to the ALB, and the frontend uses the relative URL `/api/tasks`, so there is no CORS and no backend address in frontend code. Trade-off: simplest and cheapest (one ALB). The alternative (separate ALBs or a proxy on the frontend) costs more or adds moving parts.

**Status:** Tested locally (CRUD API, frontend serving, TLS-only Postgres with CA verification). NOT tested: anything on AWS (EC2, RDS, ALB, the real RDS CA bundle). You will verify those with the checks below.

## Layout
```
backend/  server.js db.js db-check.js schema.sql package.json .env.example
frontend/ index.html
deploy/   tasks-api.service
```
API: `GET /api/health` (ALB check, no DB) | `GET /api/health/db` | `GET/POST /api/tasks` | `PUT/DELETE /api/tasks/:id`
Schema: `tasks(id serial pk, title text not null, done boolean default false, created_at timestamptz)`

## Step 1-2: Run locally
```bash
# needs Node 20+ and local Postgres
createdb tasksdb && psql tasksdb -f backend/schema.sql
cd backend && cp .env.example .env     # edit DB_USER / DB_PASSWORD
npm install && npm run dbcheck         # must print CONNECTED
npm start                              # open http://localhost:3000
```

## Step 3 prep: Network + security groups (VPC console)
Use the default VPC for learning (cost-conscious: **no NAT gateway**). EC2s sit in public subnets for package installs, but their security groups only accept traffic from the ALB. RDS is private.

| SG | Inbound | Source |
|---|---|---|
| `sg-alb` | 80 | 0.0.0.0/0 |
| `sg-frontend` | 80 | `sg-alb` |
| `sg-backend` | 3000 | `sg-alb` |
| `sg-rds` | 5432 | `sg-backend` only |
| frontend + backend | 22 (SSH) | My IP only (or use EC2 Instance Connect) |

Public: ALB. Semi-public (public IP, locked by SG): EC2s. Private: RDS (Publicly accessible = **No**).

## Step 4: RDS PostgreSQL
Console > RDS > Create database: Standard create, PostgreSQL, **Free tier** template, `db.t4g.micro`, 20 GB, DB name `tasksdb`, set master user/password, VPC = default, Public access **No**, SG = `sg-rds`. Wait for "Available", copy the **endpoint**.

**Why SSL matters:** RDS PostgreSQL 15+ defaults to `rds.force_ssl=1`, so non-encrypted clients get `no pg_hba.conf entry ... no encryption`. Fix = the client must use TLS. Do it properly: encrypt **and verify** the server certificate against the AWS CA.

Backend EC2 (Amazon Linux 2023, t3.micro, in `sg-backend`):
```bash
sudo dnf install -y nodejs git postgresql15      # psql client for testing
mkdir -p ~/app && cd ~/app                       # copy project here (git clone or scp)
cd backend && npm install --omit=dev
mkdir certs && curl -o certs/global-bundle.pem https://truststore.pki.rds.amazonaws.com/global/global-bundle.pem
cp .env.example .env && chmod 600 .env
```
Edit `.env`: `DB_HOST=<rds-endpoint>`, `DB_PORT=5432`, `DB_NAME=tasksdb`, `DB_USER`/`DB_PASSWORD` = yours, `DB_SSL=true`, `DB_SSL_CA_PATH=./certs/global-bundle.pem`, `SERVE_FRONTEND=false`.

**Connectivity test (do this before anything else):**
```bash
nc -zv <rds-endpoint> 5432                       # 1. network + SG path
npm run dbcheck                                  # 2. expect: CONNECTED, SSL in use: true
PGPASSWORD=... psql "host=<endpoint> dbname=tasksdb user=<user> sslmode=verify-full sslrootcert=certs/global-bundle.pem" -f schema.sql   # 3. create the table
```

## Step 3/6: Run the backend as a service
```bash
sudo cp ~/app/deploy/tasks-api.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now tasks-api
curl localhost:3000/api/health ; curl localhost:3000/api/health/db
```

## Step 5: Frontend EC2 (in `sg-frontend`)
```bash
sudo dnf install -y nginx && sudo systemctl enable --now nginx
sudo cp frontend/index.html /usr/share/nginx/html/index.html
curl localhost/            # returns the HTML
```

## Step 7: ALB (EC2 console > Load Balancers)
1. Target groups (type Instance, HTTP): `tg-frontend` port 80, health path `/`; `tg-backend` port 3000, health path `/api/health`. Register the matching instance in each.
2. Create ALB: internet-facing, 2+ AZ subnets, `sg-alb`, listener HTTP:80 default action = forward to `tg-frontend`.
3. Listener rule: IF path `/api/*` THEN forward to `tg-backend`.
4. Wait until both targets show **healthy**.

## Step 8: Test end to end
```bash
curl http://<alb-dns>/                  # HTML
curl http://<alb-dns>/api/health/db     # {"db":"ok",...}
```
Then open `http://<alb-dns>/` and add, edit, tick and delete tasks. Reload to confirm persistence.

## Step 9: Troubleshooting
| Symptom | Cause | Fix |
|---|---|---|
| `no pg_hba.conf entry ... no encryption` | Client not using TLS | `DB_SSL=true` + CA path |
| `UNABLE_TO_VERIFY_LEAF_SIGNATURE` / `self-signed certificate in certificate chain` | Wrong or missing CA bundle | Re-download `global-bundle.pem`, check `DB_SSL_CA_PATH`. Do **not** set `rejectUnauthorized:false` |
| `ERR_TLS_CERT_ALTNAME_INVALID` | Connected by IP or wrong host | Use the RDS endpoint DNS name |
| `ENOENT ... global-bundle.pem` | Bad cert path | Check relative path vs service `WorkingDirectory` |
| Timeout / `ETIMEDOUT` | SG or subnet path | `sg-rds` must allow 5432 from `sg-backend`; test with `nc -zv` |
| `28P01 password authentication failed` | Wrong creds | Check `.env`, no stray spaces/quotes |
| `3D000 database does not exist` | Wrong `DB_NAME` | Use the initial DB name set at creation |
| `42P01 relation "tasks" does not exist` | Schema not applied | Run `schema.sql` via psql |
| Target unhealthy | Wrong port/path, service down, SG | `systemctl status tasks-api`, `curl localhost:3000/api/health`, `sg-backend` allows 3000 from `sg-alb` |
| 502/504 from ALB | Target down or SG blocked | Same as above; check the target group's Targets tab |
| `/api/...` returns the frontend HTML | Listener rule missing/priority | Check `/api/*` rule exists |

Never commit `.env` or `*.pem`. Credentials live only in `.env` on the backend EC2 (mode 600). For production, move them to Secrets Manager.

## Clean up (avoid charges)
Delete ALB, target groups, both EC2s, the RDS instance (skip final snapshot for a lab), and security groups.

## What you can explain in an interview
Three-tier separation; SG-to-SG rules instead of IP allow-lists; private RDS; why health checks should not depend on the DB; path-based ALB routing; TLS with CA verification vs disabling verification; why the RDS error occurred and how each failure mode shows up.

# AWS 3-Tier Task Manager (v2: automated deployment)

```
Internet -> ALB :80 --/api/*--> EC2 backend :3000 --TLS (verified)--> RDS PostgreSQL :5432 (private)
                    \--default--> EC2 frontend :80 (nginx)
```
Everything is defined in `deploy/cloudformation.yaml` and shipped with three scripts. The older click-through guide is in `MANUAL-DEPLOY.md` (read it first if you want to understand each resource).

## What's new vs v1
- **One-command deploy** (CloudFormation): SGs, RDS, 2 EC2, ALB, target groups, path rule, IAM.
- **No SSH, no passwords in files:** access via SSM Session Manager; RDS generates the master password in **Secrets Manager**; the backend's IAM role is the only thing allowed to read it.
- **Deploy gate:** `setup-backend.sh` runs a TLS-verified DB check (`npm run dbcheck`) and applies the schema with `psql sslmode=verify-full` before starting the API. A broken RDS link fails loudly at deploy time.
- **Hardening:** IMDSv2 only, encrypted RDS, SG-to-SG rules only, non-root service user, systemd sandboxing, input validation, graceful shutdown.
- **Code updates without redeploying infra:** `update.sh` (S3 + SSM Run Command).

## Deploy (use AWS CloudShell in ap-south-1, or any shell with AWS CLI v2, zip and admin-ish credentials)
```bash
# upload/unzip this project, then from its root:
bash deploy/deploy.sh            # ~10-15 min (RDS is the slow part). Prints the AppUrl.
curl http://<AppUrl>/api/health/db       # expect {"db":"ok",...}
bash deploy/update.sh            # ship code changes later
bash deploy/destroy.sh           # delete EVERYTHING (stops charges)
```
Debug an instance: EC2 console > Connect > Session Manager, then `sudo cat /var/log/cloud-init-output.log` (first boot) or `sudo journalctl -u tasks-api -e` (backend).

## Verification status
| Verified (sandbox) | NOT verified (needs your AWS account) |
|---|---|
| CRUD API, validation, graceful shutdown (real Postgres) | Stack creation, RDS, ALB, IAM, SSM, S3 flow |
| TLS: no-SSL error reproduced; correct CA OK; wrong CA / IP mismatch rejected | Real `global-bundle.pem` download and RDS cert |
| `cfn-lint` clean; `bash -n` on all scripts; `nginx -t` OK | The user-data scripts running on Amazon Linux 2023 |

If `deploy.sh` fails, the CloudFormation Events tab shows the first failed resource. If the stack succeeds but targets stay unhealthy, read `cloud-init-output.log` on that instance.

## Costs & notes
Approx.: 2x t3.micro + db.t4g.micro + ALB, roughly a few USD/day, so run `destroy.sh` when done. Public IPs on the EC2s avoid a NAT gateway; they are still unreachable except via the ALB (SG rules). RDS engine version is left to the RDS default. HTTP only: for HTTPS add an ACM cert and a :443 listener. RDS has `DeletionPolicy: Delete` (lab only).

## Interview talking points
Why SG-to-SG rules; why health checks skip the DB; IAM least privilege per tier; Secrets Manager vs `.env` in git; TLS verification (CA + hostname) vs `rejectUnauthorized:false`; IaC repeatability; path-based ALB routing; trade-offs (no NAT, single AZ instances, HTTP only) and how you'd fix each for production.

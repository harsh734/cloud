const path = require('path');
const express = require('express');
const pool = require('./db');

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1);                       // we sit behind the ALB
app.use(express.json({ limit: '10kb' }));
app.use((req, res, next) => {                    // minimal security headers
  res.set('X-Content-Type-Options', 'nosniff');
  res.set('X-Frame-Options', 'DENY');
  next();
});
app.use((req, res, next) => {                    // one-line access log (goes to journald)
  const t = Date.now();
  res.on('finish', () => console.log(`${req.method} ${req.originalUrl} ${res.statusCode} ${Date.now() - t}ms`));
  next();
});

// ALB health check: does NOT touch the DB, so a DB blip doesn't mark the backend unhealthy.
app.get('/api/health', (req, res) => res.json({ status: 'ok' }));

// Separate endpoint to prove the DB link works.
app.get('/api/health/db', async (req, res) => {
  try {
    const r = await pool.query('SELECT NOW() AS now');
    res.json({ db: 'ok', now: r.rows[0].now });
  } catch (e) {
    res.status(500).json({ db: 'error', code: e.code });   // no message: don't leak internals
  }
});

const wrap = (fn) => (req, res) =>
  fn(req, res).catch((e) => { console.error(e); res.status(500).json({ error: 'server error' }); });

const validId = (req, res, next) =>
  /^\d+$/.test(req.params.id) ? next() : res.status(400).json({ error: 'invalid id' });

const cleanTitle = (v) => (typeof v === 'string' ? v.trim() : '');

app.get('/api/tasks', wrap(async (req, res) => {
  const r = await pool.query('SELECT * FROM tasks ORDER BY id DESC');
  res.json(r.rows);
}));

app.post('/api/tasks', wrap(async (req, res) => {
  const title = cleanTitle(req.body.title);
  if (!title || title.length > 200) return res.status(400).json({ error: 'title required (max 200 chars)' });
  const r = await pool.query('INSERT INTO tasks (title) VALUES ($1) RETURNING *', [title]);
  res.status(201).json(r.rows[0]);
}));

app.put('/api/tasks/:id', validId, wrap(async (req, res) => {
  const title = req.body.title === undefined ? null : cleanTitle(req.body.title);
  if (title !== null && (!title || title.length > 200)) return res.status(400).json({ error: 'bad title' });
  if (req.body.done !== undefined && typeof req.body.done !== 'boolean') return res.status(400).json({ error: 'bad done' });
  const r = await pool.query(
    'UPDATE tasks SET title = COALESCE($1, title), done = COALESCE($2, done) WHERE id = $3 RETURNING *',
    [title, req.body.done ?? null, req.params.id]);
  if (!r.rowCount) return res.status(404).json({ error: 'not found' });
  res.json(r.rows[0]);
}));

app.delete('/api/tasks/:id', validId, wrap(async (req, res) => {
  const r = await pool.query('DELETE FROM tasks WHERE id = $1', [req.params.id]);
  if (!r.rowCount) return res.status(404).json({ error: 'not found' });
  res.status(204).end();
}));

if (process.env.SERVE_FRONTEND === 'true') {
  app.use(express.static(path.join(__dirname, '../frontend')));
}

const port = process.env.PORT || 3000;
const server = app.listen(port, () => console.log(`API listening on :${port}`));

// Graceful shutdown (systemd stop / deploys): finish requests, close DB pool.
const shutdown = () => server.close(() => pool.end().then(() => process.exit(0)));
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

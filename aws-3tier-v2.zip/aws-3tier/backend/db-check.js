// Run on the backend EC2:  npm run dbcheck
const pool = require('./db');
(async () => {
  try {
    const r = await pool.query(
      "SELECT version(), current_user, (SELECT ssl FROM pg_stat_ssl WHERE pid = pg_backend_pid()) AS ssl");
    console.log('CONNECTED as', r.rows[0].current_user);
    console.log('SSL in use:', r.rows[0].ssl);
    console.log(r.rows[0].version);
    process.exit(0);
  } catch (e) {
    console.error('CONNECTION FAILED:', e.code || '', e.message);
    process.exit(1);
  }
})();

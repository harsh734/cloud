require('dotenv').config();
const fs = require('fs');
const { Pool } = require('pg');

// NOTE: discrete env vars, NOT a connection string with ?sslmode=...,
// because node-postgres handles sslmode in URLs inconsistently.
const config = {
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT || 5432),
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  connectionTimeoutMillis: 5000,
};

if (process.env.DB_SSL === 'true') {
  // Encrypt AND verify: trust only the AWS RDS CA bundle. The pg client also
  // checks the server hostname against the certificate, so connect using the
  // RDS endpoint DNS name, never its IP.
  config.ssl = {
    ca: fs.readFileSync(process.env.DB_SSL_CA_PATH, 'utf8'),
    rejectUnauthorized: true,
  };
}

module.exports = new Pool(config);

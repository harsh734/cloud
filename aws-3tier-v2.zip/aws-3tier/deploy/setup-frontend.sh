#!/bin/bash
# Runs as root on the frontend EC2. Idempotent.
set -euo pipefail
APP=/opt/app
dnf install -y nginx >/dev/null
cp "$APP/frontend/index.html" /usr/share/nginx/html/index.html
cp "$APP/deploy/nginx.conf" /etc/nginx/nginx.conf
nginx -t
systemctl enable nginx >/dev/null 2>&1
systemctl restart nginx
curl -fs localhost/healthz >/dev/null && echo ">> Frontend healthy"

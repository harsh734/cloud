#!/bin/bash
# First-time deploy of the whole stack. Run from project root (AWS CloudShell works well):  bash deploy/deploy.sh [stack-name]
set -euo pipefail
source deploy/lib.sh
package_and_upload

VPC=$(aws ec2 describe-vpcs --filters Name=isDefault,Values=true --query 'Vpcs[0].VpcId' --output text)
read -r SUBNET_A SUBNET_B < <(aws ec2 describe-subnets --filters Name=vpc-id,Values="$VPC" Name=default-for-az,Values=true \
  --query 'Subnets[0:2].SubnetId' --output text)
echo ">> VPC $VPC  subnets $SUBNET_A $SUBNET_B"

aws cloudformation deploy --stack-name "$STACK" --template-file deploy/cloudformation.yaml \
  --capabilities CAPABILITY_IAM \
  --parameter-overrides VpcId="$VPC" SubnetA="$SUBNET_A" SubnetB="$SUBNET_B" ArtifactBucket="$BUCKET" ArtifactKey="$KEY"

aws cloudformation describe-stacks --stack-name "$STACK" --query 'Stacks[0].Outputs' --output table
echo "Instances take ~3-5 min after the stack finishes to install and become healthy in the ALB."

#!/bin/bash
# Tear everything down to stop charges: bash deploy/destroy.sh [stack-name]
set -euo pipefail
source deploy/lib.sh
aws cloudformation delete-stack --stack-name "$STACK"
aws cloudformation wait stack-delete-complete --stack-name "$STACK"
aws s3 rb "s3://$BUCKET" --force
echo ">> Deleted stack and artifact bucket"

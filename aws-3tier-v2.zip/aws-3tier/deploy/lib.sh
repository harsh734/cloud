# Shared helpers for deploy.sh / update.sh / destroy.sh (run from the project root).
STACK="${1:-tasks-3tier}"
REGION="${AWS_REGION:-ap-south-1}"
export AWS_DEFAULT_REGION="$REGION"
ACCOUNT=$(aws sts get-caller-identity --query Account --output text)
BUCKET="tasks-artifacts-$ACCOUNT-$REGION"
KEY="app-latest.zip"

package_and_upload() {
  aws s3api head-bucket --bucket "$BUCKET" 2>/dev/null || {
    echo ">> Creating artifact bucket $BUCKET"
    aws s3api create-bucket --bucket "$BUCKET" --create-bucket-configuration LocationConstraint="$REGION" >/dev/null
    aws s3api put-public-access-block --bucket "$BUCKET" \
      --public-access-block-configuration BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true
  }
  rm -f /tmp/app.zip
  zip -qr /tmp/app.zip backend frontend deploy -x '*/node_modules/*' '*.env' '*.pem'
  aws s3 cp /tmp/app.zip "s3://$BUCKET/$KEY" --only-show-errors
  echo ">> Uploaded s3://$BUCKET/$KEY"
}

#!/bin/bash
# Runs as root on the backend EC2. Idempotent: safe to re-run (refresh.sh does).
set -euo pipefail
source /etc/tasks-app.env
APP=/opt/app

dnf install -y nodejs postgresql15 >/dev/null
id tasksapi &>/dev/null || useradd --system --home "$APP" --shell /sbin/nologin tasksapi

cd "$APP/backend"
npm install --omit=dev --no-audit --no-fund
mkdir -p certs
curl -fsSL -o certs/global-bundle.pem https://truststore.pki.rds.amazonaws.com/global/global-bundle.pem

# Credentials come from Secrets Manager (RDS-managed master password). Never in git/templates.
SECRET=$(aws secretsmanager get-secret-value --secret-id "$SECRET_ARN" --query SecretString --output text)
DB_USER=$(echo "$SECRET" | node -pe 'JSON.parse(require("fs").readFileSync(0,"utf8")).username')
DB_PASS=$(echo "$SECRET" | node -pe 'JSON.parse(require("fs").readFileSync(0,"utf8")).password')

umask 077
cat > .env <<ENV
PORT=3000
DB_HOST=$DB_HOST
DB_PORT=$DB_PORT
DB_NAME=$DB_NAME
DB_USER=$DB_USER
DB_PASSWORD="$DB_PASS"
DB_SSL=true
DB_SSL_CA_PATH=$APP/backend/certs/global-bundle.pem
SERVE_FRONTEND=false
ENV
chown -R tasksapi:tasksapi "$APP/backend"

# 1) Connectivity gate: fail the deployment early, with a readable error, if the DB link is broken.
echo ">> Testing RDS connection (TLS + certificate verification)"
runuser -u tasksapi -- npm run dbcheck --silent

# 2) Apply schema (idempotent: CREATE TABLE IF NOT EXISTS), with full verification via psql too.
PGPASSWORD="$DB_PASS" psql "host=$DB_HOST port=$DB_PORT dbname=$DB_NAME user=$DB_USER sslmode=verify-full sslrootcert=$APP/backend/certs/global-bundle.pem" -v ON_ERROR_STOP=1 -f schema.sql

cp "$APP/deploy/tasks-api.service" /etc/systemd/system/tasks-api.service
systemctl daemon-reload
systemctl enable tasks-api >/dev/null 2>&1
systemctl restart tasks-api

for i in $(seq 1 20); do
  curl -fs localhost:3000/api/health >/dev/null && { echo ">> Backend healthy"; exit 0; }
  sleep 1
done
echo "Backend did not become healthy; see: journalctl -u tasks-api" >&2; exit 1

#!/bin/bash
# Ship new code to the running instances (no stack changes): bash deploy/update.sh [stack-name]
set -euo pipefail
source deploy/lib.sh
package_and_upload
for ROLE in backend frontend; do
  ID=$(aws ssm send-command --document-name AWS-RunShellScript \
    --targets "Key=tag:Role,Values=$ROLE" "Key=tag:Project,Values=$STACK" \
    --parameters "commands=[\"bash /opt/app/deploy/refresh.sh $ROLE\"]" \
    --query Command.CommandId --output text)
  echo ">> $ROLE update started (command $ID). Check: aws ssm list-command-invocations --command-id $ID --details"
done

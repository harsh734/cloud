#!/bin/bash
# On the instance: pull the latest artifact from S3 and re-run this role's setup. Usage: refresh.sh backend|frontend
set -euo pipefail
source /etc/tasks-app.env
aws s3 cp "$ARTIFACT_S3" /tmp/app.zip
unzip -oq /tmp/app.zip -d /opt/app
bash "/opt/app/deploy/setup-$1.sh"
